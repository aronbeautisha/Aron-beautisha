// Simple Button Interaction

document.querySelector(".btn").addEventListener("click", function(event){

  event.preventDefault(); // Prevents opening email immediately

  alert("Thank you for reaching out, I will contact you soon!");

  window.location.href = "mailto:beauti@gmail.com"; // Opens email after alert

});